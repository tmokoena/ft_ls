/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memset.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/05/22 10:12:37 by tmokoena          #+#    #+#             */
/*   Updated: 2019/06/29 10:14:10 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memset(void *res, int c, size_t len)
{
	char	*ptr;
	int		i;

	i = len - 1;
	ptr = (char *)res;
	while (i >= 0)
	{
		ptr[i] = c;
		i--;
	}
	return (ptr);
}
