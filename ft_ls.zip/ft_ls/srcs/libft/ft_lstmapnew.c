/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstmapnew.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/06/28 15:52:27 by tmokoena          #+#    #+#             */
/*   Updated: 2019/06/28 15:57:30 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

t_list		*ft_lstmapnew(void const *content, size_t content_size)
{
	t_list	*lst;

	if (!content)
		return (NULL);
	if (!(lst = (t_list*)malloc(sizeof(t_list))))
		return (NULL);
	if (!(lst->content = malloc(sizeof(lst->content))))
		return (NULL);
	ft_memcpy(lst->content, content, content_size);
	lst->content_size = content_size;
	lst->next = NULL;
	return (lst);
}
