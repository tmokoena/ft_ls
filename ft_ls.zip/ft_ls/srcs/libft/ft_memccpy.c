/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_memccpy.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/05/27 11:44:04 by tmokoena          #+#    #+#             */
/*   Updated: 2019/06/29 10:10:31 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	*ft_memccpy(void *dst, const void *src, int c, size_t n)
{
	unsigned char			*d;
	unsigned const char		*s;
	unsigned int			i;

	if (!dst && !src)
		return (NULL);
	i = 0;
	d = dst;
	s = src;
	if (d == s)
		return (d);
	while (i != n)
	{
		d[i] = s[i];
		if (s[i] == (unsigned char)c)
		{
			return (&d[i + 1]);
		}
		i++;
	}
	return (NULL);
}
