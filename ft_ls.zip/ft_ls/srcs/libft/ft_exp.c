/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_exp.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/06/15 14:32:16 by tmokoena          #+#    #+#             */
/*   Updated: 2019/06/29 10:01:28 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

long		ft_exp(const long x, long pow)
{
	long ans;

	ans = x;
	if (pow == 0)
		return (1);
	pow--;
	while (pow)
	{
		ans = ans * x;
		pow--;
	}
	return (ans);
}
