/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstmap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/06/28 14:50:04 by tmokoena          #+#    #+#             */
/*   Updated: 2019/06/29 10:08:47 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

t_list	*ft_lstmap(t_list *lst, t_list *(*f)(t_list *elem))
{
	t_list	*lt;
	t_list	*ret;
	t_list	*temp;

	temp = f(lst);
	if (!lst || !f)
		return (NULL);
	if (!(lt = ft_lstnew(temp->content, temp->content_size)))
		return (NULL);
	ret = lt;
	while (lst->next != NULL)
	{
		if (!(temp = f(lst)))
			return (NULL);
		if (!(lt->next = ft_lstnew(temp->content, temp->content_size)))
			return (NULL);
		lst = lst->next;
		lt = lt->next;
	}
	return (ret);
}
