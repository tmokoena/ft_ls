/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strlcat.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/06/26 14:25:55 by tmokoena          #+#    #+#             */
/*   Updated: 2019/06/29 10:25:12 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

size_t		ft_strlcat(char *dst, const char *src, size_t dstsize)
{
	size_t		i[3];

	i[0] = ft_strlen(dst);
	i[1] = ft_strlen(dst);
	i[2] = ft_strlen(src);
	if (dstsize <= i[1])
		return (i[2] + dstsize);
	while (*src && i[0] < (dstsize - 1))
	{
		dst[i[0]] = *src;
		i[0]++;
		src++;
	}
	dst[i[0]] = '\0';
	return (i[1] + i[2]);
}
