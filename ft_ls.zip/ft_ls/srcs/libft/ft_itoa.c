/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_itoa.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/06/12 15:51:52 by tmokoena          #+#    #+#             */
/*   Updated: 2019/06/29 10:08:39 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_itoa(int n)
{
	char	*ptr;
	long	nb;
	int		i;

	nb = n;
	i = ft_numlen(nb);
	if (!(ptr = (char*)malloc(sizeof(char) * (i + 1))))
		return (NULL);
	ptr[i] = '\0';
	ptr[0] = 48;
	if (n == 0)
		ptr[0] = 48;
	if (nb < 0)
	{
		ptr[0] = '-';
		nb = nb * -1;
	}
	while (nb > 0)
	{
		ptr[i - 1] = 48 + (nb % 10);
		nb = nb / 10;
		i--;
	}
	return (ptr);
}
