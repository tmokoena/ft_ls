/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_atoi.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/05/23 12:07:45 by tmokoena          #+#    #+#             */
/*   Updated: 2019/06/29 10:44:07 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

int		ft_atoi(const char *str)
{
	long int			i;
	long int			sign;
	long int			ans;

	ans = 0;
	if ((i = ft_getfirstprint(str, 1)) == -1)
		return (0);
	if ((sign = ft_issign(str[i])))
		i++;
	if (sign == 0)
		sign = 1;
	while (str[i] && ft_isdigit(str[i]))
	{
		ans = (ans * 10);
		ans += ((long int)str[i] - 48);
		i++;
	}
	return (ans * sign);
}
