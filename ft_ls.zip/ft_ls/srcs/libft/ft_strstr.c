/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strstr.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/06/04 13:59:06 by tmokoena          #+#    #+#             */
/*   Updated: 2019/06/29 10:30:20 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strstr(const char *haystack, const char *needle)
{
	unsigned int i;

	i = 0;
	if ((ft_strlen(needle) > ft_strlen(needle)))
	{
		return (NULL);
	}
	else
	{
		while ((ft_strlen(haystack) - i) >= ft_strlen(needle))
		{
			if (ft_strncmp(&haystack[i], needle, ft_strlen(needle)) == 0)
			{
				return ((char*)&haystack[i]);
			}
			i++;
		}
	}
	return (NULL);
}
