/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_strnstr.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/06/29 08:46:56 by tmokoena          #+#    #+#             */
/*   Updated: 2019/06/29 11:29:42 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

char	*ft_strnstr(const char *s1, const char *needle, size_t len)
{
	size_t	i;

	if (*needle == '\0')
		return ((char *)s1);
	i = ft_strlen(needle);
	while (*s1 != '\0' && len-- >= i)
	{
		if (*s1 == *needle && ft_memcmp(s1, needle, i) == 0)
			return ((char *)s1);
		s1++;
	}
	return (NULL);
}
