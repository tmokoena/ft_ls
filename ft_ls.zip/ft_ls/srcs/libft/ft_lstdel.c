/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_lstdel.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/06/19 13:15:01 by tmokoena          #+#    #+#             */
/*   Updated: 2019/06/22 17:58:14 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "libft.h"

void	ft_lstdel(t_list **alst, void (*del)(void *, size_t))
{
	t_list *node;
	t_list *temp;

	temp = *alst;
	while (temp)
	{
		node = temp->next;
		del(temp->content, temp->content_size);
		free(temp);
		temp = node;
	}
	*alst = NULL;
}
