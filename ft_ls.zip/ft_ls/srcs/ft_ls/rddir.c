/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   rddir.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/30 10:34:14 by tmokoena          #+#    #+#             */
/*   Updated: 2020/02/18 11:47:14 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

/*
** this function reads into a specified dir and populates the files & folders
** arrays with the relecent information like, file:name,lastmoddate & f_inode
*/

int		rpcheck(char *s1)
{
	if (strcmp(s1, ".") != 0 && strcmp(s1, "..") != 0)
		return (1);
	return (0);
}

void	setdata(dl *data, struct dirent *sd)
{
	data->fname = ft_strdup(sd->d_name);
}

int		ft_rddir(char *dirname, int hidden, dl *files, dl *folders, int R)
{
	DIR				*dir;
	struct dirent	*sd;

	if (!(dir = opendir(dirname)))
		return (-1);
	while ((sd = readdir(dir)) != NULL)
	{
		if ((sd->d_name[0] != '.') && (hidden == 0))
		{
			setdata(files++, sd);
			if (sd->d_type == DT_DIR && R == 1)
				setdata(folders++, sd);
		}
		else if (hidden == 1)
		{
			setdata(files++, sd);
			if (sd->d_type == DT_DIR && R == 1 && rpcheck(sd->d_name))
				setdata(folders++, sd);
		}
	}
	closedir(dir);
	return (0);
}
