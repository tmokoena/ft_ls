/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_dirchecker.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/02/18 10:50:18 by tmokoena          #+#    #+#             */
/*   Updated: 2020/02/18 10:57:05 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

/*
**	this function checks for existance of the files or folders provided by
**	the user if the file/folder doesn't exist then print the error and if it
**	does set the direc array with the existing ones
*/

int		ft_dirchecker(char **temp, size_t size, char **direc)
{
	int			j;
	size_t		i;
	struct stat st;

	j = 0;
	i = 0;
	while (i < size)
	{
		if (stat(temp[i], &st) == -1)
			printf("ls: %s: No such file or directory\n", temp[i]);
		else
			direc[j++] = temp[i];
		i++;
	}
	return (j);
}
