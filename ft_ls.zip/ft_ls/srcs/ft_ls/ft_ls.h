/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ls.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/02/18 11:52:42 by tmokoena          #+#    #+#             */
/*   Updated: 2020/02/18 12:01:33 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

# ifndef _FT_LS_
# include <sys/types.h>
# include <sys/stat.h>
# include <dirent.h>
# include <pwd.h>
# include <grp.h>
# include "../libft/libft.h"
# include <unistd.h>
# include <stdio.h>
# include <stdlib.h>
# include <string.h>
# include <time.h>

typedef struct	t_list
{
	long int	blk;
	long int	lmod;
	char		*fname;
}				dl;

int				ft_getnf(char *dirname, int hidden);
int				ft_getnfl(char *dirname, int hidden, int R);
long int		ft_getmodsec(char *file);
void			ft_sortbyname(dl *list, int len, int r);
void			ft_sortbydate(dl *list, int len, int r);
void			ft_swaps(dl *i, dl *j);
void			ft_sortfunc(dl *f, dl *fl, int fs, int fls, int R, int r, int t);
void			ft_dft_sort(dl *f, dl *fl, int fs, int fls, int R);
int				ft_ls(char *dir, int *f);
void			ft_sortstrp(char **direc, const unsigned int size);
int				ft_dirchecker(char **temp, size_t size, char **direc);
int				lexparse(int *flags, char **direc, char **source, unsigned int *j);
int				ft_rddir(char *dirname, int hidden, dl *files, dl *folders, int R);
void			ft_print(dl *files, size_t fs, int R, int l, char *dir);
void			ft_pp(char *s, char *fname);
void			ft_lprint(dl *files, size_t fs, char *dir);
void			ft_rprint(char *dir);
void			ft_dprint(dl *files, size_t fs);
char			*ft_dirmaker(char *dir, char *nextdir);
char			ft_lchr(char *s);
void			ft_getlmod(dl *f, int fs, char *dir);
#endif
