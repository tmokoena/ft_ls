/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   l_print.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/02/18 11:40:59 by tmokoena          #+#    #+#             */
/*   Updated: 2020/02/18 11:42:15 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

char	*usid(uid_t id)
{
	struct passwd *pwd;

	pwd = getpwuid(id);
	return (pwd->pw_name);
}

char	*gid(gid_t id)
{
	struct group *grp;

	grp = getgrgid(id);
	return (grp->gr_name);
}

size_t	ft_getblock(dl *f, size_t fs)
{
	size_t i;
	size_t j;

	i = -1;
	j = 0;
	while (++i < fs)
		j += f[i].blk;
	return (j);
}

void	ft_lprint(dl *files, size_t fs, char *dir)
{
	size_t i;

	i = 0;
	printf("total %zu\n", ft_getblock(files, fs));
	while (i < fs)
	{
		ft_pp(ft_dirmaker(dir, files[i].fname), files[i].fname);
		printf("\n");
		i++;
	}
}

void	ft_ptime(char *s)
{
	size_t i;

	i = 4;
	while (i < 16)
		ft_putchar(s[i++]);
}

void	ft_perm(char *s)
{
	struct stat filestat;

	stat(s, &filestat);
	ft_putchar((S_ISDIR(filestat.st_mode)) ? 'd' : '-');
	ft_putchar((filestat.st_mode & S_IRUSR) ? 'r' : '-');
	ft_putchar((filestat.st_mode & S_IWUSR) ? 'w' : '-');
	ft_putchar((filestat.st_mode & S_IXUSR) ? 'x' : '-');
	ft_putchar((filestat.st_mode & S_IRGRP) ? 'r' : '-');
	ft_putchar((filestat.st_mode & S_IWGRP) ? 'w' : '-');
	ft_putchar((filestat.st_mode & S_IXGRP) ? 'x' : '-');
	ft_putchar((filestat.st_mode & S_IROTH) ? 'r' : '-');
	ft_putchar((filestat.st_mode & S_IWOTH) ? 'w' : '-');
	ft_putstr((filestat.st_mode & S_IXOTH) ? "x  " : "-  ");
}

void	ft_pp(char *s, char *fname)
{
	struct stat filestat;
	char		*temp;

	stat(s, &filestat);
	ft_perm(s);
	ft_putstr((temp = ft_itoa(filestat.st_nlink)));
	free(temp);
	ft_putchar('	');
	ft_putstr(usid(filestat.st_uid));
	ft_putstr("	");
	ft_putstr(gid(filestat.st_gid));
	ft_putstr("	");
	ft_putstr((temp = ft_itoa(filestat.st_size)));
	free(temp);
	ft_putchar('	');
	ft_ptime(ctime(&filestat.st_mtime));
	ft_putchar('	');
	ft_putstr(fname);
	free(s);
}
