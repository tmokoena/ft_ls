/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   getmodsec.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/13 11:47:04 by tmokoena          #+#    #+#             */
/*   Updated: 2020/02/18 11:27:48 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

/*
**	this function gets the number of seconds of the last modification time
*/

long int	ft_getmodsec(char *file)
{
	struct stat st;

	stat(file, &st);
	return (st.st_mtimespec.tv_nsec);
}
