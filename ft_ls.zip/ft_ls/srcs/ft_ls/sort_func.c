/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   sort_func.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/02/18 11:47:22 by tmokoena          #+#    #+#             */
/*   Updated: 2020/02/18 11:49:52 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

/*
** this function takes care of all types of sorting depending on
** the opitions passed in by the user
** f = files;fl = folders;fs = files size;fls = folders size then...
*/

void	ft_sortfunc(dl *f, dl *fl, int fs, int fls, int R, int r, int t)
{
	ft_dft_sort(f, fl, fs, fls, R);
	if (!R)
	{
		if (!t)
			ft_sortbyname(f, fs, r);
		else
		{
			ft_sortbydate(f, fs, r);
		}
	}
	else
	{
		if (!t)
		{
			ft_sortbyname(f, fs, r);
			ft_sortbyname(fl, fls, r);
		}
		else
		{
			ft_sortbydate(f, fs, r);
			ft_sortbydate(fl, fls, r);
		}
	}
}
