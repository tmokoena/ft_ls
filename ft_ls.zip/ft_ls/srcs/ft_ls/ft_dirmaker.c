/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_dirmaker.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/02/18 10:57:22 by tmokoena          #+#    #+#             */
/*   Updated: 2020/02/18 10:59:32 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

char	*ft_dirmaker(char *dir, char *nextdir)
{
	char *p[2];

	if (ft_lchr(dir) != '/')
	{
		p[0] = ft_strjoin(dir, "/");
		p[1] = ft_strjoin(p[0], nextdir);
		free(p[0]);
	}
	else
		p[1] = ft_strjoin(dir, nextdir);
	return (p[1]);
}
