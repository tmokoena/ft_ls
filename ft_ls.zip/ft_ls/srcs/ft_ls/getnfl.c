/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   getnfl.c                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/29 11:38:10 by tmokoena          #+#    #+#             */
/*   Updated: 2020/02/18 11:30:26 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

/*
** this function counts the number of folders inside a dir
** without the . and the .. system folders
*/

int		rootprevcheck(char *s1)
{
	if (strcmp(s1, ".") != 0 && strcmp(s1, "..") != 0)
		return (1);
	return (0);
}

/*
** the r => R meaning the small r is the big R
*/

int		ft_getnfl(char *dirname, int hidden, int R)
{
	DIR				*dir;
	struct dirent	*sd;
	int				count;

	if (!R)
		return (0);
	count = 0;
	if (!(dir = opendir(dirname)))
		return (-1);
	while ((sd = readdir(dir)))
	{
		if (sd->d_type == DT_DIR)
		{
			if (hidden == 0 && sd->d_name[0] != '.')
				count++;
			if (hidden == 1)
				if (rootprevcheck(sd->d_name))
					count++;
		}
	}
	closedir(dir);
	return (count);
}
