/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   dft_sort.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/02/18 10:42:34 by tmokoena          #+#    #+#             */
/*   Updated: 2020/02/18 10:49:41 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

void	ft_dft_sort(dl *f, dl *fl, int fs, int fls, int r)
{
	if (!r)
	{
		ft_sortbyname(f, fs, 0);
	}
	else
	{
		ft_sortbyname(f, fs, 0);
		ft_sortbyname(fl, fls, 0);
	}
}
