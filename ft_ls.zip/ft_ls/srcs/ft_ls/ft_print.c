/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/12 18:06:50 by tmokoena          #+#    #+#             */
/*   Updated: 2020/02/18 11:14:27 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

/*
** this function handles alling options handled by the ls function
** NB: r => R
*/

void	pp(dl *files, int l, size_t fs, char *dir)
{
	if (l == 0)
		ft_dprint(files, fs);
	else
		ft_lprint(files, fs, dir);
}

void	ft_print(dl *files, size_t fs, int r, int l, char *dir)
{
	if (r == 1)
	{
		ft_rprint(dir);
		pp(files, l, fs, dir);
	}
	else
		pp(files, l, fs, dir);
}
