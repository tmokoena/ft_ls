/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/12 16:41:17 by tmokoena          #+#    #+#             */
/*   Updated: 2020/02/18 12:01:52 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

/*
** takes the dl array, the length of the array and the reverse sort condition
*/

void	ft_sortbyname(dl *list, int len, int r)
{
	int i;
	int k;

	k = len;
	while (len)
	{
		i = 0;
		while (i < k - 1)
		{
			if (!r)
			{
				if (strcmp(list[i].fname, list[i + 1].fname) > 0)
					ft_swaps(&list[i], &list[i + 1]);
			}
			else if (strcmp(list[i].fname, list[i + 1].fname) < 0)
				ft_swaps(&list[i], &list[i + 1]);
			i++;
		}
		len--;
	}
}
