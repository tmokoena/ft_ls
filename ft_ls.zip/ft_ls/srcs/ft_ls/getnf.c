/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   getnf.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/07/26 11:52:21 by tmokoena          #+#    #+#             */
/*   Updated: 2020/02/18 11:28:10 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

/*
** this function counts the number of files inside a dir
*/

int		ft_getnf(char *dirname, int hidden)
{
	DIR				*dir;
	struct dirent	*sd;
	int				count;

	count = 0;
	if (!(dir = opendir(dirname)))
		return (-1);
	while ((sd = readdir(dir)) != NULL)
	{
		if ((sd->d_name[0] != '.') && (hidden == 0))
			count++;
		else if (hidden == 1)
			count++;
	}
	closedir(dir);
	return (count);
}
