/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sort.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/08/12 16:41:17 by tmokoena          #+#    #+#             */
/*   Updated: 2020/02/18 11:25:52 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

/*
** takes the dl array, the length of the array and the reverse sort condition
*/

void	ft_sortbydate(dl *list, int len, int r)
{
	int i;
	int j;
	int k;

	j = 0;
	k = len;
	while (j < len)
	{
		i = 0;
		while (i < k - 1)
		{
			if (!r)
			{
				if (list[i].lmod < list[i + 1].lmod)
					ft_swaps(&list[i], &list[i + 1]);
			}
			else if (list[i].lmod > list[i + 1].lmod)
				ft_swaps(&list[i], &list[i + 1]);
			i++;
		}
		j++;
	}
}
