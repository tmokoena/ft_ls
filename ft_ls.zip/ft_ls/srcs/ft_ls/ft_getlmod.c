/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_getlmod.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/02/18 10:59:44 by tmokoena          #+#    #+#             */
/*   Updated: 2020/02/18 11:00:59 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

void	ft_getlmod(dl *f, int fs, char *dir)
{
	int			i;
	struct stat st;
	char		*p;

	i = -1;
	while (++i < fs)
	{
		p = ft_dirmaker(dir, f[i].fname);
		stat(p, &st);
		free(p);
		f[i].lmod = st.st_mtime;
		f[i].blk = st.st_blocks;
	}
}
