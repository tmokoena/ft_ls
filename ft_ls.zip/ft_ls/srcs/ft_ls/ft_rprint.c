/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_R_print.c                                       :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/12 16:14:00 by tmokoena          #+#    #+#             */
/*   Updated: 2020/02/18 11:15:41 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

/*
** this function prints the tree before showing the files inside
** the current directory, thus the tree shows you where you are
*/

void	ft_rprint(char *dir)
{
	ft_putstr(dir);
	ft_putstr(":\n");
}
