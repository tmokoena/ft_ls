/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_ls.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/02/18 11:03:39 by tmokoena          #+#    #+#             */
/*   Updated: 2020/02/18 11:11:54 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

/*
** f = Flags (a =f[0] R=f[1] r=f[2] t=f[3] l=f[4]
*/

void	ft_farrs(dl *f, int fs, dl *fd, int fds, size_t flag)
{
	while (--fs >= 0)
		free(f[fs].fname);
	if (flag == 1)
		while (--fds >= 0)
			free(fd[fds].fname);
}

int		ft_ls(char *dir, int *f)
{
	size_t	i[4];
	char	*p;
	dl		fls[i[1] = ft_getnf(dir, f[0])];
	dl		flds[i[2] = ft_getnfl(dir, f[0], f[1])];

	i[0] = 0;
	if (ft_rddir(dir, f[0], fls, flds, f[1]) == -1)
		return (-1);
	ft_getlmod(fls, i[1], dir);
	ft_sortfunc(fls, flds, i[1], i[2], f[1], f[2], f[3]);
	ft_print(fls, i[1], f[1], f[4], dir);
	while (i[0] < i[2])
	{
		p = ft_dirmaker(dir, flds[i[0]++].fname);
		ft_ls(p, f);
		free(p);
	}
	ft_farrs(fls, i[1], flds, i[2], f[1]);
	return (0);
}
