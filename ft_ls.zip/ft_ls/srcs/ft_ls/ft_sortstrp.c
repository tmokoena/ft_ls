/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_sortstrp.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/02/18 11:26:06 by tmokoena          #+#    #+#             */
/*   Updated: 2020/02/18 11:27:13 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

void	ft_sortstrp(char **direc, const unsigned int size)
{
	char			*p;
	unsigned int	i;
	unsigned int	j;

	j = 0;
	i = 0;
	p = 0;
	while (i < size)
	{
		j = 0;
		while ((j + 1) < size)
		{
			if (ft_strcmp(direc[j], direc[j + 1]) > 0)
			{
				p = direc[j];
				direc[j] = direc[j + 1];
				direc[j + 1] = p;
				p = 0;
			}
			j++;
		}
		i++;
	}
}
