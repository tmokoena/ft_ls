/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   lexp.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2020/02/18 11:45:31 by tmokoena          #+#    #+#             */
/*   Updated: 2020/02/18 11:45:46 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_ls.h"

int		checker(char *s, int *flags)
{
	int	i;

	i = 1;
	if (*s == '-')
		while (s[i])
		{
			if (s[i] == 'a')
				flags[0] = 1;
			else if (s[i] == 'R')
				flags[1] = 1;
			else if (s[i] == 'r')
				flags[2] = 1;
			else if (s[i] == 't')
				flags[3] = 1;
			else if (s[i] == 'l')
				flags[4] = 1;
			else
				return (-1);
			i++;
		}
	return (0);
}

int		lexparse(int *flags, char **direc, char **source, unsigned int *j)
{
	int i;

	i = 1;
	while (source[i] && source[i][0] == '-')
	{
		if ((checker(source[i], flags)) == -1)
			return (-1);
		i++;
	}
	if (source[i] != 0)
		while (source[i])
		{
			direc[*j] = source[i];
			*j += 1;
			i++;
		}
	ft_sortstrp(direc, *j);
	return (0);
}
