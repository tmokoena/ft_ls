/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tmokoena <marvin@42.fr>                    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2019/09/11 16:59:14 by tmokoena          #+#    #+#             */
/*   Updated: 2019/12/07 13:29:02 by tmokoena         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../srcs/ft_ls/ft_ls.h"

void	ferr(void)
{
	printf("ls: illegal option -- -\nusage: ls [alRrt] [file ...]");
}

void	ft_ini(char **temp, const unsigned int tempvar, char **direc)
{
	if (tempvar > 0)
	{
		if (ft_dirchecker(temp, tempvar, direc) == 0)
			direc[0] = ".";
	}
	else
		direc[0] = ".";
}

int		main(int c, char *v[])
{
	char			*tree[1024];
	char			*direc[1024];
	int				flags[5];
	unsigned int	stk;
	unsigned int	i;

	(void)c;
	i = 0;
	stk = 0;
	if (lexparse(flags, tree, v, &stk) == -1)
	{
		ferr();
		return (0);
	}
	ft_ini(tree, stk, direc);
	while (direc[i])
		ft_ls(direc[i++], flags);
	return (0);
}
